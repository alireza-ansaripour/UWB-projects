void seed(int s);
int getRandom();